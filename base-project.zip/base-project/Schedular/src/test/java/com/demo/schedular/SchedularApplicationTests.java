package com.demo.schedular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedularApplicationTests {

    @Test
    void contextLoads() {
    }

}
